![Ekran görüntüsü 2023-12-24 225959](https://github.com/ErayKeles/Akka-ile-basit-bir-aktor-sistemi/assets/128937269/feafd9a1-1c40-4f30-a8fe-c7b350e7b96c)
![Ekran görüntüsü 2023-12-24 225943](https://github.com/ErayKeles/Akka-ile-basit-bir-aktor-sistemi/assets/128937269/ba2c84a5-ec3e-4228-ae00-4150e198a68f)
